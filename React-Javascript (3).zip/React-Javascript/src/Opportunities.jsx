import React, { useState } from 'react';
import { Plus, MapPin, Calendar, Clock, AlertCircle, FileText } from 'lucide-react';
import './Opportunities.css';

export default function Opportunities() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    campName: '',
    location: '',
    date: '',
    description: '',
    duration: '',
    durationUnit: 'Days',
    urgency: 'Medium'
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    // Log the complete form data
    console.log('Campaign Details Submitted:', {
      'Camp Name': formData.campName,
      'Location': formData.location,
      'Date': formData.date,
      'Duration': `${formData.duration} ${formData.durationUnit}`,
      'Urgency': formData.urgency,
      'Description': formData.description
    });
    
    // Show confirmation message
    setIsSubmitted(true);
    
    // Reset form data
    setFormData({
      campName: '',
      location: '',
      date: '',
      description: '',
      duration: '',
      durationUnit: 'Days',
      urgency: 'Medium'
    });
  };

  const handleCancel = () => {
    setIsModalOpen(false);
    setIsSubmitted(false);
    // Reset form
    setFormData({
      campName: '',
      location: '',
      date: '',
      description: '',
      duration: '',
      durationUnit: 'Days',
      urgency: 'Medium'
    });
  };

  const handleClose = () => {
    setIsModalOpen(false);
    setIsSubmitted(false);
  };

  return (
    <div className="opportunities-container">
      <h1>Opportunities</h1>
      <button
        className="add-campaign-btn"
        onClick={() => setIsModalOpen(true)}
      >
        <Plus size={20} />
        Add Campaign
      </button>

      {isModalOpen && (
        <div className="modal-overlay">
          <div className="modal">
            {!isSubmitted ? (
              <>
                <h2>Add Campaign</h2>
                <form onSubmit={handleSubmit}>
              <div className="form-group">
                <label htmlFor="campName">Camp Name</label>
                <div className="input-with-icon">
                  <FileText className="input-icon" size={18} />
                  <input
                    type="text"
                    id="campName"
                    name="campName"
                    value={formData.campName}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="location">Location</label>
                <div className="input-with-icon">
                  <MapPin className="input-icon" size={18} />
                  <input
                    type="text"
                    id="location"
                    name="location"
                    value={formData.location}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="date">Date</label>
                <div className="input-with-icon">
                  <Calendar className="input-icon" size={18} />
                  <input
                    type="date"
                    id="date"
                    name="date"
                    value={formData.date}
                    onChange={handleInputChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="description">Description</label>
                <div className="input-with-icon">
                  <FileText className="input-icon textarea-icon" size={18} />
                  <textarea
                    id="description"
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows="4"
                    required
                  />
                </div>
              </div>

              <div className="form-group">
                <label>Duration</label>
                <div className="duration-input-group">
                  <div className="input-with-icon">
                    <Clock className="input-icon" size={18} />
                    <input
                      type="number"
                      id="duration"
                      name="duration"
                      value={formData.duration}
                      onChange={handleInputChange}
                      required
                      className="duration-value-input"
                    />
                  </div>
                  <select
                    id="durationUnit"
                    name="durationUnit"
                    value={formData.durationUnit}
                    onChange={handleInputChange}
                    required
                    className="duration-unit-select"
                  >
                    <option value="Days">Days</option>
                    <option value="Hours">Hours</option>
                  </select>
                </div>
              </div>

              <div className="form-group">
                <label htmlFor="urgency">Urgency</label>
                <div className="input-with-icon">
                  <AlertCircle className="input-icon" size={18} />
                  <select
                    id="urgency"
                    name="urgency"
                    value={formData.urgency}
                    onChange={handleInputChange}
                    required
                  >
                    <option value="Low">Low</option>
                    <option value="Medium">Medium</option>
                    <option value="High">High</option>
                  </select>
                </div>
              </div>

              <div className="modal-buttons">
                    <button
                      type="button"
                      className="cancel-btn"
                      onClick={handleCancel}
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="submit-btn"
                    >
                      Submit
                    </button>
                  </div>
                </form>
              </>
            ) : (
              <div className="confirmation-message">
                <h2>Details Submitted!</h2>
                <p>Your campaign details have been successfully submitted.</p>
                <button
                  type="button"
                  className="submit-btn"
                  onClick={handleClose}
                >
                  Close
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}