import './App.css'
import Opportunities from './Opportunities'

export default function App() {
  return (
    <main>
      <Opportunities />
    </main>
  )
}
