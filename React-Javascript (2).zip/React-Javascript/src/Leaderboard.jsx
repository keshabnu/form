
import { useState } from 'react'
import './Leaderboard.css'
import PerksGuide from './PerksGuide'

const mockUsers = [
  { id: 1, name: "Alex Chauhan", points: 2450, avatar: "AC" },
  { id: 2, name: "Marina karki", points: 2180, avatar: "MR" },
  { id: 3, name: "David khadka", points: 1950, avatar: "DK" },
  { id: 4, name: "Sarah ban", points: 1720, avatar: "SJ" },
  { id: 5, name: "Michael luitel", points: 1580, avatar: "MB" },
  { id: 6, name: "Eshan limbu", points: 1420, avatar: "EW" },
  { id: 7, name: "James Davis", points: 1250, avatar: "JD" },
  { id: 8, name: "Lisa Anderson", points: 1100, avatar: "LA" },
  { id: 9, name: "Ryan Thompson", points: 950, avatar: "RT" },
  { id: 10, name: "Sophie Miller", points: 820, avatar: "SM" },
  { id: 11, name: "Kevin Lee", points: 680, avatar: "KL" },
  { id: 12, name: "Rachel Green", points: 540, avatar: "RG" },
  { id: 13, name: "Tom Harris", points: 420, avatar: "TH" },
  { id: 14, name: "Anna Clark", points: 310, avatar: "AC" },
  { id: 15, name: "Jake Martinez", points: 180, avatar: "JM" }
]

function getTier(points) {
  if (points >= 5000) return { name: "God of Kindness", color: "#4CAF50", borderColor: "linear-gradient(45deg, #4CAF50, #FFD700)", icon: "👑" }
  if (points >= 3000) return { name: "Platinum", color: "#00C0FF", borderColor: "#00C0FF", icon: "💎" }
  if (points >= 2000) return { name: "Gold", color: "#FFD700", borderColor: "#FFD700", icon: "🥇" }
  if (points >= 1000) return { name: "Silver", color: "#C0C0C0", borderColor: "#C0C0C0", icon: "🥈" }
  return { name: "Bronze", color: "#CD7F32", borderColor: "#CD7F32", icon: "🥉" }
}

function getNextTier(points) {
  if (points >= 5000) return null // Max tier reached
  if (points >= 3000) return { name: "God of Kindness", pointsNeeded: 5000, icon: "🌟" }
  if (points >= 2000) return { name: "Platinum", pointsNeeded: 3000, icon: "💎" }
  if (points >= 1000) return { name: "Gold", pointsNeeded: 2000, icon: "🥇" }
  return { name: "Silver", pointsNeeded: 1000, icon: "🥈" }
}

function getDisplayTier(points, position) {
  // Top 2 users get Champion title
  if (position === 1 || position === 2) {
    return { name: "🏆 Champion", color: "#2E7D32", borderColor: "#2E7D32", icon: "🏆" }
  }
  return getTier(points)
}

function getNextTierForTopUsers(points, position) {
  // For top 2 users, always show next as God of Kindness
  if (position === 1 || position === 2) {
    return { name: "God of Kindness", pointsNeeded: 5000, icon: "🌟" }
  }
  return getNextTier(points)
}

function getPerk(points) {
  if (points >= 3000) return { text: "Team Leader Access", icon: "🍃" }
  if (points >= 2000) return { text: "Community Spotlight", icon: "⭐" }
  if (points >= 1000) return { text: "Priority Signup", icon: "🔑" }
  return { text: "Starter Badge", icon: "🏆" }
}

function getAllPerks(points) {
  const allPerks = [
    { level: "Bronze", perk: "Starter Badge", icon: "🏆", threshold: 0, unlocked: points >= 0 },
    { level: "Silver", perk: "Priority Signup", icon: "🔑", threshold: 1000, unlocked: points >= 1000 },
    { level: "Gold", perk: "Community Spotlight", icon: "⭐", threshold: 2000, unlocked: points >= 2000 },
    { level: "Platinum", perk: "Team Leader Access", icon: "🍃", threshold: 3000, unlocked: points >= 3000 },
    { level: "God of Kindness", perk: "Community Hero", icon: "👑", threshold: 5000, unlocked: points >= 5000 }
  ]
  return allPerks
}

function getProgressToNext(points) {
  if (points >= 5000) return { current: points, max: points, percentage: 100 }
  if (points >= 3000) return { current: points - 3000, max: 2000, percentage: ((points - 3000) / 2000) * 100 }
  if (points >= 2000) return { current: points - 2000, max: 1000, percentage: ((points - 2000) / 1000) * 100 }
  if (points >= 1000) return { current: points - 1000, max: 1000, percentage: ((points - 1000) / 1000) * 100 }
  return { current: points, max: 1000, percentage: (points / 1000) * 100 }
}

function Avatar({ initials }) {
  return (
    <div className="avatar">
      {initials}
    </div>
  )
}

function ProgressBar({ percentage }) {
  return (
    <div className="progress-bar">
      <div className="progress-fill" style={{ width: `${percentage}%` }}></div>
    </div>
  )
}

function Badge({ badge }) {
  return (
    <span className="badge" style={{ backgroundColor: badge.color }}>
      {badge.name}
    </span>
  )
}

function TopThreeCard({ user, position }) {
  const actualTier = getTier(user.points)
  const progress = getProgressToNext(user.points)
  
  // Determine border color based on actual tier or champion status
  let borderColor = actualTier.borderColor
  if (position === 1 || position === 2) {
    borderColor = "#2E7D32" // Champion green
  }
  
  const cardStyle = actualTier.name === "God of Kindness" 
    ? { 
        border: `4px solid transparent`,
        background: `linear-gradient(white, white) padding-box, linear-gradient(45deg, #4CAF50, #FFD700) border-box`
      }
    : { borderColor: borderColor }
  
  // Plain text titles and next achievements - hardcoded exactly as specified
  let titleText = ""
  let nextText = ""
  
  if (position === 1) {
    titleText = "Champion"
    nextText = "Next: God of Kindness at 5000 pts"
  } else if (position === 2) {
    titleText = "Champion"
    nextText = "Next: God of Kindness at 5000 pts"
  } else if (position === 3) {
    titleText = "Current Tier: Gold"
    nextText = "Next: Platinum at 3000 pts"
  }
  
  return (
    <div className={`top-three-card position-${position}`} style={cardStyle}>
      <div className="position-number">{position}</div>
      <Avatar initials={user.avatar} />
      <h3 className="user-name">{user.name}</h3>
      <div className="points">{user.points.toLocaleString()} pts</div>
      <div className="tier-badge" style={{ borderColor: borderColor }}>
        <span className="tier-name">{titleText}</span>
      </div>
      <div className="next-tier">
        {nextText}
      </div>
      <div className="progress-section">
        <ProgressBar percentage={progress.percentage} />
        <span className="progress-text">
          {progress.current}/{progress.max}
        </span>
      </div>
    </div>
  )
}

function LeaderboardRow({ user, rank }) {
  const tier = getTier(user.points)
  const progress = getProgressToNext(user.points)
  
  const rowStyle = tier.name === "God of Kindness" 
    ? { 
        border: `2px solid transparent`,
        background: `linear-gradient(white, white) padding-box, linear-gradient(45deg, #4CAF50, #FFD700) border-box`
      }
    : { borderColor: tier.borderColor }
  
  // Plain text current tier and next achievement - hardcoded based on points
  let currentTierText = ""
  let nextText = ""
  
  if (user.points >= 5000) {
    currentTierText = "Current Tier: God of Kindness"
    nextText = "Max tier achieved!"
  } else if (user.points >= 3000) {
    currentTierText = "Current Tier: Platinum"
    nextText = "Next: God of Kindness at 5000 pts"
  } else if (user.points >= 2000) {
    currentTierText = "Current Tier: Gold"
    nextText = "Next: Platinum at 3000 pts"
  } else if (user.points >= 1000) {
    currentTierText = "Current Tier: Silver"
    nextText = "Next: Gold at 2000 pts"
  } else {
    currentTierText = "Current Tier: Bronze"
    nextText = "Next: Silver at 1000 pts"
  }
  
  return (
    <div className="leaderboard-row" style={rowStyle}>
      <div className="rank">#{rank}</div>
      <Avatar initials={user.avatar} />
      <div className="user-info">
        <div className="name-tier">
          <span className="name">{user.name}</span>
          <div className="tier-badge small" style={{ borderColor: tier.borderColor }}>
            <span className="tier-name">{currentTierText}</span>
          </div>
        </div>
        <div className="next-tier small">
          {nextText}
        </div>
        <div className="progress-section">
          <ProgressBar percentage={progress.percentage} />
          <span className="progress-text">
            {progress.current}/{progress.max}
          </span>
        </div>
      </div>
      <div className="points">{user.points.toLocaleString()}</div>
    </div>
  )
}

function Profile({ user, onBackToLeaderboard }) {
  const allPerks = getAllPerks(user.points)
  const tier = getTier(user.points)
  
  return (
    <div className="leaderboard-container">
      <div className="leaderboard-card">
        <div className="profile-header">
          <button className="back-button" onClick={onBackToLeaderboard}>
            ← Back to Leaderboard
          </button>
          <h1 className="profile-title">Profile</h1>
        </div>
        
        <div className="profile-info">
          <Avatar initials={user.avatar} />
          <h2 className="profile-name">{user.name}</h2>
          <div className="profile-points">{user.points.toLocaleString()} points</div>
          <div className="tier-badge" style={{ backgroundColor: tier.color }}>
            <span className="tier-icon">{tier.icon}</span>
            <span className="tier-name">{tier.name}</span>
          </div>
        </div>
        
        <div className="perks-section">
          <h3 className="perks-title">Perks Unlocked</h3>
          <div className="perks-list">
            {allPerks.map((perk, index) => (
              <div key={index} className={`perk-item ${perk.unlocked ? 'unlocked' : 'locked'}`}>
                <div className="perk-level">{perk.level}</div>
                <div className="perk-description">
                  <span className="perk-icon">{perk.icon}</span>
                  <span className="perk-text">{perk.perk}</span>
                </div>
                <div className="perk-status">
                  {perk.unlocked ? (
                    <span className="status-unlocked">✓ Unlocked</span>
                  ) : (
                    <span className="status-locked">{perk.threshold} pts required</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}

export default function Leaderboard() {
  const [selectedUser, setSelectedUser] = useState(null)
  const [showPerksGuide, setShowPerksGuide] = useState(false)
  const sortedUsers = [...mockUsers].sort((a, b) => b.points - a.points)
  const topThree = sortedUsers.slice(0, 3)
  const remaining = sortedUsers.slice(3)
  
  if (showPerksGuide) {
    return <PerksGuide userPoints={selectedUser?.points || 0} onBackToLeaderboard={() => setShowPerksGuide(false)} />
  }
  
  if (selectedUser) {
    return <Profile user={selectedUser} onBackToLeaderboard={() => setSelectedUser(null)} />
  }
  
  return (
    <div className="leaderboard-container">
      <div className="leaderboard-card">
        <div className="leaderboard-header">
          <h1 className="leaderboard-title">Eco Leaderboard</h1>
          <button className="perks-guide-button" onClick={() => setShowPerksGuide(true)}>
            View Perks Guide
          </button>
        </div>
        
        <div className="top-three-section">
          <div onClick={() => setSelectedUser(topThree[1])}>
            <TopThreeCard user={topThree[1]} position={2} />
          </div>
          <div onClick={() => setSelectedUser(topThree[0])}>
            <TopThreeCard user={topThree[0]} position={1} />
          </div>
          <div onClick={() => setSelectedUser(topThree[2])}>
            <TopThreeCard user={topThree[2]} position={3} />
          </div>
        </div>
        
        <div className="remaining-section">
          {remaining.map((user, index) => (
            <div key={user.id} onClick={() => setSelectedUser(user)}>
              <LeaderboardRow 
                user={user} 
                rank={index + 4} 
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
